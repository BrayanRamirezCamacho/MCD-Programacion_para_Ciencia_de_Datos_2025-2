# ---------------------------------------------
# Función principal de normalización de strings
# ---------------------------------------------
def normalizar_producto(p):
    if pd.isna(p):
        return None
    
    # pasar a minúsculas
    p = p.lower()
    
    # eliminar acentos usando unicodedata (estándar)
    p = ''.join(
        c for c in unicodedata.normalize('NFD', p)
        if unicodedata.category(c) != 'Mn'
    )
    
    # reemplazar cualquier cosa que no sea letra/número/espacio
    p = re.sub(r"[^a-z0-9 ]", " ", p)
    
    # colapsar espacios múltiples
    p = re.sub(r"\s+", " ", p).strip()
    
    return p

# -------------------------------------------------------------------------------
# Función auxiliar de procesamiento de strings: extraer número antes de unidad
# -------------------------------------------------------------------------------
def extraer_numero(texto, patron):
    m = re.search(patron, texto)
    if m:
        return float(m.group(1))
    return None

# -------------------------------------------
# Función principal de estimación de volumen
# -------------------------------------------
def estimar_volumen(texto):
    texto = texto.lower()

    # ----------------------------
    # 1. Detectar ml y litros
    # ----------------------------
    ml = extraer_numero(texto, r"(\d+)\s*ml")
    if ml:
        return ml  # 1 ml = 1 cm3

    litros = extraer_numero(texto, r"(\d+(\.\d+)?)\s*l")
    if litros:
        return litros * 1000

    # ----------------------------
    # 2. Detectar masa (g o kg)
    # ----------------------------
    gramos = extraer_numero(texto, r"(\d+)\s*g(?!ranel)")  # evitar capturar "granel 1 kg"
    if not gramos:
        kg = extraer_numero(texto, r"(\d+)\s*kg")
        if kg:
            gramos = kg * 1000

    if gramos:
        # Buscar palabras clave para densidad
        for palabra, densidad in DENSIDADES.items():
            if palabra in texto:
                return gramos / densidad
        
        # Si no se identifica categoría, asumir densidad agua
        return gramos / 1.0

    # ----------------------------
    # 3. Medicamentos (tabletas, cápsulas, etc.)
    # ----------------------------
    if any(x in texto for x in ["tableta", "tabletas", "cápsula", "capsula", "cpsula", "comprimido"]):
        # Buscar número de unidades
        unidades = extraer_numero(texto, r"(\d+)\s*(tableta|cápsula|capsula|cpsula|comprimido)")
        if unidades:
            # Heurística: 2–3 cm3 por tableta en caja compacta
            return unidades * 2.5
        # Si no se detecta número, asignar tamaño de caja pequeño
        return 30

    # Ampolletas y jeringas
    if "ampolleta" in texto or "jeringa" in texto:
        ml = extraer_numero(texto, r"(\d+)\s*ml")
        if ml:
            # Añadir volumen del empaque
            return ml + 20  
        return 40  # estimación genérica

    # ----------------------------
    # 4. Granel ("1 kg granel")
    # ----------------------------
    if "granel" in texto:
        gramos = extraer_numero(texto, r"(\d+)\s*kg")
        if gramos:
            gramos *= 1000
            # Densidad promedio de alimentos frescos
            return gramos / 0.95
        return 800  # estimación genérica

    # ----------------------------
    # 5. Volumen estándar por envase
    # ----------------------------
    for palabra, vol in VOLUMEN_STANDAR.items():
        if palabra in texto:
            return vol

    # ----------------------------
    # 6. Si nada funcionó, devolver NaN
    # ----------------------------
    return np.nan

# ----------------------------
# Muestreo aleatorio simple
# ----------------------------
def muestrear_solucion(df, C):
    vol = df["volumen_estimado_cm3"].values
    n = len(vol)
    solucion = np.zeros(n, dtype=int)
    
    capacidad_restante = C
    
    # Lista de índices de productos que pueden caber
    indices_validos = [i for i in range(n) if vol[i] > 0]
    
    while True:
        # Filtrar solo productos que aún caben
        caben = [i for i in indices_validos if vol[i] <= capacidad_restante]
        if not caben:
            break  # no cabe nada más
        
        # Elegir uno al azar
        i = random.choice(caben)
        
        # Agregarlo
        solucion[i] += 1
        capacidad_restante -= vol[i]
    
    return solucion

# ----------------------------
# Temple Simulado
# ----------------------------
import math

def simulated_annealing_knapsack(values, weights, W,
                                 T_init=1000,     # Temperatura inicial
                                 T_min=1e-3,      # Temperatura mínima
                                 alpha=0.99,      # Factor de enfriamiento
                                 max_iter=5000):  # Número máximo de iteraciones

    n = len(values)

    # -------------------------
    # Funciones auxiliares
    # -------------------------

    def peso(sol):
        return sum(sol[i] * weights[i] for i in range(n))

    def valor(sol):
        return sum(sol[i] * values[i] for i in range(n))

    def generar_vecino(sol):
        """
        Genera una solución vecina modificando ligeramente la actual:
        - Incrementa o decrementa la cantidad de un ítem.
        - Repara la solución si excede la capacidad.
        """
        nueva = sol[:]

        i = random.randint(0, n - 1)

        # Decide si sumar o restar unidades
        if random.random() < 0.5:
            nueva[i] += 1
        else:
            if nueva[i] > 0:
                nueva[i] -= 1

        # Reparar si excede la capacidad
        while peso(nueva) > W:
            j = random.randint(0, n - 1)
            if nueva[j] > 0:
                nueva[j] -= 1

        return nueva

    # -------------------------
    # Inicializar solución
    # -------------------------
    solucion_actual = [0] * n
    mejor_solucion = solucion_actual[:]

    T = T_init

    # -------------------------
    # Bucle principal del temple simulado
    # -------------------------
    for _ in range(max_iter):

        vecino = generar_vecino(solucion_actual)

        delta = valor(vecino) - valor(solucion_actual)

        # Regla de aceptación
        if delta > 0:
            solucion_actual = vecino
        else:
            prob = math.exp(delta / T)
            if random.random() < prob:
                solucion_actual = vecino

        # Actualizar mejor solución encontrada
        if valor(solucion_actual) > valor(mejor_solucion):
            mejor_solucion = solucion_actual[:]

        # Enfriamiento
        T *= alpha
        if T < T_min:
            break

    # -------------------------
    # Retorno final
    # -------------------------
    return mejor_solucion, valor(mejor_solucion), peso(mejor_solucion)